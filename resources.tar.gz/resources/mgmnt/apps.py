from django.apps import AppConfig


class MgmntConfig(AppConfig):
    name = 'mgmnt'
